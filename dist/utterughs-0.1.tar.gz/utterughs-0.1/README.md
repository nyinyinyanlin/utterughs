# UTTER-UGHS

Bored of an afternoon or is your boss annoying you? Spit an ugh out!! 

```Python
from utterughs import ughs

print(ughs())
```